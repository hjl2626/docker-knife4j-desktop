Knife4jAggregationDesktop是一款独立部署的OpenAPI规范渲染服务软件,支持OpenAPI2及OpenAPI3规范

同时支持Disk、Cloud、Eureka、Nacos四种不同的模式进行聚合显示

作者：八一菜刀

邮箱：xiaoymin@foxmail.com

官网介绍：https://doc.xiaominfo.com/knife4j/documentation/knife4jAggregationDesktop.html

源码地址:https://doc.xiaominfo.com/knife4j/documentation/sourcecode.html